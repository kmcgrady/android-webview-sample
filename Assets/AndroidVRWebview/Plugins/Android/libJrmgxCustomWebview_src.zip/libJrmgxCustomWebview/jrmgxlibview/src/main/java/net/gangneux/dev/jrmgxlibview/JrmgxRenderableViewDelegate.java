package net.gangneux.dev.jrmgxlibview;

@SuppressWarnings("WeakerAccess")
public interface JrmgxRenderableViewDelegate {
    void sendMessage(String message);
}
